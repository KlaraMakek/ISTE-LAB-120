/** class- draw and redraw simple drawing
 * @author Klara Makek
 * @version 16.9.2022.
 */
public class TestPicture {
    public static void main(String[] args) throws Exception {
    /*
     * the picture is initialize and drawn
     */
    Picture picture = new Picture();
    picture.draw();
    }
}
