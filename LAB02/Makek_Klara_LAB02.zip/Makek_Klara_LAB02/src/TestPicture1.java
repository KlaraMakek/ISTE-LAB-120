/** class- draw and redraw simple drawing
 * @author Klara Makek
 * @version 16.9.2022.
 */
public class TestPicture1 {

    public static void main(String[] args) throws Exception {
    /*
     * the picture is initialize and drawn
     */
    Picture1 picture1 = new Picture1();
    picture1.draw();
    }
}
