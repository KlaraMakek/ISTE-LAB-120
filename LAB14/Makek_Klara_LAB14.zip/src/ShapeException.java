/**
 * Circle
 * @author Klara Makek
 * @version 5.12.2022.
 * Course: ISTE-120
 * LAB 14
 */
 /**************JAVADOC************************/
public class ShapeException extends Exception {
    public ShapeException(String message){
        super(message);
    }
}
